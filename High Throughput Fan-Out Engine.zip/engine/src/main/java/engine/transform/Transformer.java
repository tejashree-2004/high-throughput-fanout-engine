package engine.transform;

public interface Transformer {
    String transform(String input);
}

