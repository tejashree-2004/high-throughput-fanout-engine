package engine.config;

public class AppConfig {

    public static int QUEUE_SIZE = 1000;
    public static double REST_RATE = 50;
    public static double DB_RATE = 100;
    public static int THREADS = 4;
}

